package com.iftm.api.atividade02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade02ApplicationTests {

    @Test
    void contextLoads() {
    }

}

package iftm;

public class B {
    public B (){
        System.out.println("Classe B");
    }
}

package iftm;

public class C extends A{
    private B b = new B();
}

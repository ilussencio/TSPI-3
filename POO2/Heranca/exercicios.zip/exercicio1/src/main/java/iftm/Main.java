package iftm;

public class Main {
    public static void main(String[] args) {
        C c = new C();
    }
}
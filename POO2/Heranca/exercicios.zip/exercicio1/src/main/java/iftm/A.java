package iftm;

public class A {
    public A (){
        System.out.println("Classe A");
    }
}

package iftm;

public class Main {
    public static void main(String[] args) {
        Amigo amigo = new Amigo("João", "Masculino", 20, "01/01/2000");
    }
}